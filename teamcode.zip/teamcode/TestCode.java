package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.modernrobotics.ModernRoboticsTouchSensor;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import org.firstinspires.ftc.robotcore.external.Telemetry;

@TeleOp

public class TestCode extends LinearOpMode{
    private DcMotor motor1;
    private DcMotor motor2;
    private DcMotor motor3;
    private DcMotor motor4;

    private double width = 0.4191; //meters
    private double length = 0.4250;
    private double wheelRad = 0.0444;
    private double maxWheelSpeed = 68;
    private double maxBodyVel= 3;
    private double maxRotationSpeed = 1;


    @Override
    public void runOpMode() {
        motor1 = hardwareMap.get(DcMotor.class, "motor1");
        motor2 = hardwareMap.get(DcMotor.class, "motor2");
        motor3 = hardwareMap.get(DcMotor.class, "motor3");
        motor4 = hardwareMap.get(DcMotor.class, "motor4");

        telemetry.addData("Status", "Initialized");
        waitForStart();

        motor1.setDirection(DcMotorSimple.Direction.REVERSE);
        motor2.setDirection(DcMotorSimple.Direction.FORWARD);
        motor3.setDirection(DcMotorSimple.Direction.FORWARD);
        motor4.setDirection(DcMotorSimple.Direction.REVERSE);

        double xIn;
        double yIn;
        double rotIn;
        while (opModeIsActive()) {
            xIn = -this.gamepad1.left_stick_y;
            yIn = -this.gamepad1.left_stick_x;
            rotIn = -this.gamepad1.right_stick_x;

            // Mappint inputs to desired velocity
            double xVel = (Math.abs(xIn) < 0.3) ? 0 : ((xIn / 1.0) * maxBodyVel);
            double yVel = (Math.abs(yIn) < 0.3) ? 0 : ((yIn / 1.0) * maxBodyVel);
            double omega = (Math.abs(rotIn) < 0.3) ? 0 : ((rotIn / 1.0) * maxBodyVel);

            // TODO: Decrease sensitivity
            double[] wheelSpeeds = calcVelocity(xVel, yVel, omega);
            motor1.setPower(getMotorPower(wheelSpeeds[0]));
            motor2.setPower(getMotorPower(wheelSpeeds[1]));
            motor3.setPower(getMotorPower(wheelSpeeds[2]));
            motor4.setPower(getMotorPower(wheelSpeeds[3]));

            telemetry.addData("X Input:", xIn);
            telemetry.addData("Y Input:", yIn);
            telemetry.addData("Rotational Input", rotIn);
            telemetry.addData("X Velocity", xVel);
            telemetry.addData("Y Velocity", yVel);
            telemetry.addData("Z Velocity", omega);
            telemetry.addData("motor1 Speed:", wheelSpeeds[0]);
            telemetry.addData("motor2 Speed:", wheelSpeeds[1]);
            telemetry.addData("motor3 Speed:", wheelSpeeds[2]);
            telemetry.addData("motor4 Speed:", wheelSpeeds[3]);
            telemetry.addData("motor1 Power:", motor1.getPower());
            telemetry.addData("motor2 Power:", motor2.getPower());
            telemetry.addData("motor3 Power:", motor3.getPower());
            telemetry.addData("motor4 Power:", motor4.getPower());

            telemetry.update();
        }
    }

     public double[] calcVelocity(double xVel, double yVel, double omega){
         double wheelSpeeds[] = new double[4];

         wheelSpeeds[0] = (omega * (-1 * length - width) + xVel - yVel) /wheelRad ;
         wheelSpeeds[1] = (omega * (length + width) + xVel + yVel) /wheelRad ;
         wheelSpeeds[2] = (omega * (length + width) + xVel - yVel) /wheelRad ;
         wheelSpeeds[3] = (omega * (-1 * length - width) + xVel + yVel) /wheelRad ;

         return wheelSpeeds;
    }

    public double getMotorPower(double wheelSpeed){
        return wheelSpeed / maxWheelSpeed;
    }
}

